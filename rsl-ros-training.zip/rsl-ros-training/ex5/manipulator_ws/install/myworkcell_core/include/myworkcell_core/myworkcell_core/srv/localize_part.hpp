// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef MYWORKCELL_CORE__SRV__LOCALIZE_PART_HPP_
#define MYWORKCELL_CORE__SRV__LOCALIZE_PART_HPP_

#include "myworkcell_core/srv/detail/localize_part__struct.hpp"
#include "myworkcell_core/srv/detail/localize_part__builder.hpp"
#include "myworkcell_core/srv/detail/localize_part__traits.hpp"

#endif  // MYWORKCELL_CORE__SRV__LOCALIZE_PART_HPP_
