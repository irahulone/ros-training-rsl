// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef FAKE_AR_PUBLISHER__MSG__AR_MARKER_HPP_
#define FAKE_AR_PUBLISHER__MSG__AR_MARKER_HPP_

#include "fake_ar_publisher/msg/detail/ar_marker__struct.hpp"
#include "fake_ar_publisher/msg/detail/ar_marker__builder.hpp"
#include "fake_ar_publisher/msg/detail/ar_marker__traits.hpp"

#endif  // FAKE_AR_PUBLISHER__MSG__AR_MARKER_HPP_
