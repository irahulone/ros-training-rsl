// generated from rosidl_generator_c/resource/idl.h.em
// with input from fake_ar_publisher:msg/ARMarker.idl
// generated code does not contain a copyright notice

#ifndef FAKE_AR_PUBLISHER__MSG__AR_MARKER_H_
#define FAKE_AR_PUBLISHER__MSG__AR_MARKER_H_

#include "fake_ar_publisher/msg/detail/ar_marker__struct.h"
#include "fake_ar_publisher/msg/detail/ar_marker__functions.h"
#include "fake_ar_publisher/msg/detail/ar_marker__type_support.h"

#endif  // FAKE_AR_PUBLISHER__MSG__AR_MARKER_H_
